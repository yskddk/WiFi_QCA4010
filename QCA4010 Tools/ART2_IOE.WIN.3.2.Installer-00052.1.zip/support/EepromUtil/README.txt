[Txt2Bin]
It will generate a NewBoardData.bin
command:
eepromTxt2Bin_ar6004.exe eeprom_2_1.tpl NewBoardData.txt NewBoardData.bin

[Bin2Txt]
Command:
eepromBin2Txt_ar6004.exe eeprom_2_1.tpl NewBoardData.bin NewBoardData.txt